import 'package:flutter/material.dart';
import 'package:saver_gallery/saver_gallery.dart';
import 'package:http/http.dart' as http;
import 'dart:typed_data';

class WallpaperPreview extends StatelessWidget {
  final String imageUrl;

  const WallpaperPreview({super.key, required this.imageUrl});

  Future<void> _downloadImage(BuildContext context) async {
    try {
      // Fetch image data as bytes
      final response = await http.get(Uri.parse(imageUrl));
      if (response.statusCode == 200) {
        Uint8List bytes = response.bodyBytes;

        // Generate a unique filename
        String fileName =
            "wallpaper_${DateTime.now().millisecondsSinceEpoch}.jpg";

        // Save the image using saver_gallery
        final result = await SaverGallery.saveImage(
          bytes,
          fileName: fileName, // Required: Set the file name
          skipIfExists: false, // Required: Set to false to allow overwriting
          androidRelativePath: "Pictures/Wallpapers",
        );

        if (result.isSuccess) {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Wallpaper saved successfully!')),
          );
        } else {
          ScaffoldMessenger.of(context).showSnackBar(
            const SnackBar(content: Text('Failed to save wallpaper!')),
          );
        }
      } else {
        ScaffoldMessenger.of(context).showSnackBar(
          const SnackBar(content: Text('Failed to download wallpaper!')),
        );
      }
    } catch (e) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Error: $e')),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Wallpaper Preview')),
      body: Column(
        children: [
          Expanded(
            child: Image.network(imageUrl, fit: BoxFit.cover),
          ),
          Padding(
            padding: const EdgeInsets.all(16.0),
            child: ElevatedButton(
              onPressed: () => _downloadImage(context),
              child: const Text('Download Wallpaper'),
            ),
          ),
        ],
      ),
    );
  }
}
