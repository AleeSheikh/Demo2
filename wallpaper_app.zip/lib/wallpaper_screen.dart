import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:http/http.dart' as http;
import 'package:cached_network_image/cached_network_image.dart';
import 'wallpaper_preview.dart';

// 🔥 Hardcoded Pexels API Key
const String apiKey =
    '1YHfiLC04bNgTfIYUzJQxcs2OmSOtzkdBza3hx0ZrKGB6OfIRlS9PcbI';
const String baseUrl = 'https://api.pexels.com/v1/';

class WallpaperScreen extends StatefulWidget {
  const WallpaperScreen({super.key});

  @override
  _WallpaperScreenState createState() => _WallpaperScreenState();
}

class _WallpaperScreenState extends State<WallpaperScreen> {
  List wallpapers = [];
  String selectedCategory = 'Recent';
  bool isSearchOpen = false;
  final TextEditingController _searchController = TextEditingController();

  @override
  void initState() {
    super.initState();
    fetchWallpapers('curated'); // Load default wallpapers
  }

  Future<void> fetchWallpapers(String query) async {
    final url = query == 'curated'
        ? '$baseUrl/curated?per_page=30'
        : '$baseUrl/search?query=$query&per_page=30';

    final response =
        await http.get(Uri.parse(url), headers: {'Authorization': apiKey});

    if (response.statusCode == 200) {
      setState(() {
        wallpapers = jsonDecode(response.body)['photos'];
      });
    } else {
      throw Exception('Failed to load wallpapers');
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: isSearchOpen
            ? TextField(
                controller: _searchController,
                decoration: const InputDecoration(
                  hintText: 'Search wallpapers...',
                  border: InputBorder.none,
                ),
                onSubmitted: (query) {
                  setState(() => selectedCategory = query);
                  fetchWallpapers(query);
                },
              )
            : Text(selectedCategory),
        actions: [
          IconButton(
            icon: Icon(isSearchOpen ? Icons.close : Icons.search),
            onPressed: () {
              setState(() {
                isSearchOpen = !isSearchOpen;
                if (!isSearchOpen) {
                  _searchController.clear();
                  fetchWallpapers('curated');
                }
              });
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: [
            const DrawerHeader(
              decoration: BoxDecoration(color: Colors.blue),
              child: Text('Categories',
                  style: TextStyle(fontSize: 22, color: Colors.white)),
            ),
            ListTile(
              title: const Text('Recent'),
              onTap: () {
                setState(() => selectedCategory = 'Recent');
                fetchWallpapers('curated');
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: const Text('Nature'),
              onTap: () {
                setState(() => selectedCategory = 'Nature');
                fetchWallpapers('nature');
                Navigator.pop(context);
              },
            ),
            ListTile(
              title: const Text('Abstract'),
              onTap: () {
                setState(() => selectedCategory = 'Abstract');
                fetchWallpapers('abstract');
                Navigator.pop(context);
              },
            ),
          ],
        ),
      ),
      body: wallpapers.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : GridView.builder(
              padding: const EdgeInsets.all(8),
              itemCount: wallpapers.length,
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 3, // 3 wallpapers per row
                crossAxisSpacing: 4,
                mainAxisSpacing: 4,
              ),
              itemBuilder: (context, index) {
                String imageUrl = wallpapers[index]['src']['medium'];
                return GestureDetector(
                  onTap: () => Navigator.push(
                    context,
                    MaterialPageRoute(
                      builder: (context) =>
                          WallpaperPreview(imageUrl: imageUrl),
                    ),
                  ),
                  child: CachedNetworkImage(
                    imageUrl: imageUrl,
                    fit: BoxFit.cover,
                  ),
                );
              },
            ),
    );
  }
}
